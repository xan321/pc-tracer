﻿using UnityEngine;
using System.Collections;

public class MenuNavigation : MonoBehaviour
{


	void OnMouseEnter()
	{
		GetComponent<Renderer>().material.color = Color.grey;

	}
	void OnMouseExit()
	{
		GetComponent<Renderer>().material.color = Color.black;

	}
}

