﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    public int SettingsScene = 4;
    public int LoaderNewGameScene = 2;
    public int DictionaryScene = 5;
    public int FreeBuildScene = 6;
    public int MenuScene = 1;


    public void NewGame()
    {
        SceneManager.LoadScene(LoaderNewGameScene);
    }

    public void Settings()
    {
        SceneManager.LoadScene(SettingsScene);
    }

    public void Dictionary()
    {
        SceneManager.LoadScene(DictionaryScene);
    }

    public void FreeBuild()
    {
        SceneManager.LoadScene(FreeBuildScene);
    }

    public void BackToMenu()
    {
        SceneManager.LoadScene(MenuScene);
    }

    public void Exit()
    {
        Application.Quit();
    }
}
